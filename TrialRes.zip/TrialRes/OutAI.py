from openai import OpenAI
client = OpenAI(
    api_key="",
)
def get_completion(prompt):
    return client.chat.completions.create(
        messages=[
            {
                "role": "user",
                "content": prompt,
            }
        ],
        model="gpt-3.5-turbo",
    )